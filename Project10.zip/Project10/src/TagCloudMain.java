/**
 * The main class creates the tag cloud object.
 *
 * @author Chandler Gerstenslager & Reece Partridge
 * @version 11/29/17
 *
 */
public final class TagCloudMain {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudMain() {
    }

    /**
     * Main method. Creates the TagCloud object which then returns the correct
     * HTML output.
     *
     * @param args
     *            The arugments.
     */
    public static void main(String[] args) {
        // create HTML tag cloud object
        new TagCloud();
    }
}
