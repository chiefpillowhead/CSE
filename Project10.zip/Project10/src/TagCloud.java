import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;

import components.map.Map;
import components.map.Map.Pair;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;

/**
 * Put a short phrase describing the program here.
 *
 * @authors Chandler Gerstenslager & Reece Partridge
 * @version 11/28/17
 *
 */
public final class TagCloud {

    /*
     * Private variables -------------------------------------------------------
     */

    /**
     * The SimpleReader that reads the input file.
     */
    private BufferedReader inputReader;

    /**
     * The SimpleWriter that prints to the output HTML file.
     */
    private PrintStream outputWriter;

    /**
     * The map that contains all the words of the input file and their
     * corresponding counts.
     */
    private HashMap<String, Integer> wordCount;

    /*
     * Private methods ---------------------------------------------------------
     */

    /**
     * This method adds all the words in the input file to this.wordCount and
     * keeps count of the words.
     *
     * @param input
     *            The SimpleReader inside the input file.
     */
    private void wordAndCountMap(BufferedReader input) {
        /*
         * While loop will continue until it goes through all the words in input
         */
        try {
            while (input.ready()) {
                String content = input.readLine(); //holds the nextLine of input
                int length = content.length();
                int position = 0; //start at position 0 in content
                String word = "";
                // We built the StringBuffer because FindBugs was giving us a warning
                StringBuffer wordBuilder = new StringBuffer();
                while (position < length) {
                    // gets the character at the position
                    char character = content.charAt(position);
                    boolean isCharacter = Character.isLetter(character)
                            || character == '\'';
                    if (isCharacter) { // if it is a character
                        while (isCharacter) { // while it is a word
                            /*
                             * While the loop keeps getting characters, it will
                             * concatenate the characters to the end of the
                             * WordBuider until it reaches an invalid char
                             */
                            character = Character.toLowerCase(character);
                            wordBuilder.append(character);
                            position++; //increases the position
                            if (position != length) {
                                character = content.charAt(position);
                                isCharacter = Character.isLetter(character)
                                        || character == '\'';
                            } else {
                                /*
                                 * If it reaches the length, there are no more
                                 * characters left.
                                 */
                                isCharacter = false;
                            }
                        }
                        // turns the StringBuffer into a string
                        word = wordBuilder.toString();
                        // checks to see if the word is in the map
                        boolean wordIsInMap = this.wordCount.containsKey(word);
                        if (wordIsInMap) {
                            int occurances = this.wordCount.remove(word);
                            int incrementCount = occurances + 1;
                            this.wordCount.put(word, incrementCount);
                        } else {
                            this.wordCount.put(word, 1);
                        }
                        position++; //increments the position
                        word = ""; //resets the word string
                        wordBuilder.setLength(0);
                    } else {
                        position++; // if it's not a valid char, increments the position
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Cannot read from file.");
        }

    }

    /**
     * The sorting machine the the pair's values from greatest to least order
     * based off their key values, and then grabs the top [code: wordsToDisplay]
     * values from greatest to least. Once it does that, it sorts those pairs
     * alphabetically by their key.
     *
     * @param wordCount2
     *            The map of the words (the key) and count (the value).
     * @param wordsToDisplay
     *            The number of words that will be displayed in the final HTML
     *            doc.
     * @return Returns the sorting machine with the ordered words.
     */
    public SortingMachine<Map.Pair<String, Integer>> sortedMap(
            HashMap<String, Integer> wordCount2, int wordsToDisplay) {

        /*
         * Sorts the values of each Map.Pair from greatest to least
         */
        Comparator<Map.Pair<String, Integer>> compareValues = new CompareMapValues();
        SortingMachine<Map.Pair<String, Integer>> sort = new SortingMachine1L<>(
                compareValues);

        // Adds the pairs from the map to the sorting machine
        for (Map.Pair<String, Integer> x : wordCount2) {
            sort.add(x);
        }

        sort.changeToExtractionMode();

        /*
         * Sorts the keys of each Map.Pair alphabetically
         */
        Comparator<Map.Pair<String, Integer>> compareWord = new CompareMapKeys();
        SortingMachine<Map.Pair<String, Integer>> wordSort = new SortingMachine1L<>(
                compareWord);

        /*
         * Adds the pairs from the map to the sorting machine and sorts them
         * alphabetically
         */

        for (int i = 0; i < wordsToDisplay; i++) {
            Map.Pair<String, Integer> mapPair = sort.removeFirst();
            wordSort.add(mapPair);
        }

        wordSort.changeToExtractionMode();

        return wordSort;

    }

    /**
     * This creates the HTML file.
     *
     * @param out
     *            Prints the HTML to the output file.
     * @param sortPair
     *            This is the sorting machine with the sorted map pairs.
     * @param words
     *            The number of words that will be in the document.
     * @param inputtedPath
     *            The path of the input file.
     */
    public void createHtml(PrintStream out,
            SortingMachine<Map.Pair<String, Integer>> sortPair, int words,
            String inputtedPath) {
        out.println("<html>");
        out.println("<head>");
        out.println("<title>");
        out.println("Top " + words + " words in " + inputtedPath);
        out.println("</title>");
        out.println("<link href=\"http://cse.osu.edu/software/2231/web-sw2/"
                + "assignments/projects/tag-cloud-generator/data/tagcloud.css\""
                + " rel=\"stylesheet\" type=\"text/css\">");
        out.println("</head>");

        out.println("<body>");
        out.println("<h2>");
        out.println("Top " + words + " words in " + inputtedPath);
        out.println("</h2>");
        out.println("<hr>");

        out.println("<div class=\"cdiv\">");
        out.println("<p class=\"cbox\">");
        for (int i = 0; i < words; i++) {
            Map.Pair<String, Integer> check = sortPair.removeFirst();
            String word = check.key();
            int count = check.value();
            int fontSize = 11 + (count / 28); // magic number bs.
            out.println("<span style=\"cursor:default\" class=\"f" + fontSize
                    + "\" title=\"count: " + count + "\">");
            out.println(word);
            out.println("</span>");
        }
        out.println("</p>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    /*
     * Creator of initial representation. --------------------------------------
     */

    /**
     * Creator of initial representation of Tag Cloud HTML object.
     */
    private void createNewRep() {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter the full path to the input file: ");
        String inputFile = in.nextLine();
        System.out.println("Please enter the full path to the input file: ");
        String outputFile = in.nextLine();
        System.out.println("How many words would you like in your tag cloud? ");
        int numberOfWords = in.nextInt();

        try {
            this.inputReader = new BufferedReader(new FileReader(inputFile));
            this.outputWriter = new PrintStream(
                    new FileOutputStream(outputFile));
        } catch (FileNotFoundException e) {
            System.out.println("Cannot instantiate reader or writer to files.");
        }
        this.wordCount = new HashMap<String, Integer>();
        this.wordAndCountMap(this.inputReader);
        SortingMachine<Map.Pair<String, Integer>> sortedPairs = this
                .sortedMap(this.wordCount, numberOfWords);
        this.createHtml(this.outputWriter, sortedPairs, numberOfWords,
                inputFile);
        this.outputWriter.close();
        in.close();
    }

    /*
     * Constructors ------------------------------------------------------------
     */

    /**
     * Constructor of the initial representation which calls createNewRep.
     */
    public TagCloud() {
        this.createNewRep();
    }

    /*
     * Private nested classes --------------------------------------------------
     *
     * These are public methods that can be accessed from the TagCloudMain
     * class.
     */

    /**
     * This class provides the method to comapre the keys of the 2 maps.
     *
     * @author Chandler and Reece
     *
     */
    public static class CompareMapKeys
            implements Comparator<Map.Pair<String, Integer>> {

        /**
         * Private constructor so this utility class cannot be instantiated.
         */
        public CompareMapKeys() {
        }

        /**
         * This compares the keys from two map key pairs.
         */
        @Override
        public int compare(Pair<String, Integer> arg0,
                Pair<String, Integer> arg1) {
            return arg0.key().compareTo(arg1.key());
        }
    }

    /**
     * This class provides the methods to compare the values of the 2 maps.
     *
     * @author Chandler and Reece
     */
    public static class CompareMapValues
            implements Comparator<Map.Pair<String, Integer>> {

        /**
         * Private constructor so this utility class cannot be instantiated.
         */
        public CompareMapValues() {
        }

        /**
         * This compares the values from two map value pairs.
         */
        @Override
        public int compare(Pair<String, Integer> o1, Pair<String, Integer> o2) {
            return o2.value().compareTo(o1.value());
        }
    }
}
