import components.map.Map;
import components.map.Map1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;

/**
 * Put a short phrase describing the program here.
 *
 * @authors Chandler Gerstenslager & Reece Partridge
 * @version 11/28/17
 *
 */
public final class TagCloud {

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        /*
         * User enters input and output files here.
         */
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.println("Please enter the full path to the input file: ");
        String inputFile = in.nextLine();
        out.println("Please enter the full path to the input file: ");
        String outputFile = in.nextLine();
        out.println("How many words would you like in your tag cloud? ");
        int numberOfWords = in.nextInteger();
        // create HTML tag cloud object
        new TagCloud(inputFile, outputFile, numberOfWords);
        in.close();
        out.close();
    }

    /*
     * Private variables -------------------------------------------------------
     */

    /**
     * The SimpleReader that reads the input file.
     */
    private SimpleReader inputReader;

    /**
     * The SimpleWriter that prints to the output HTML file.
     */
    private SimpleWriter outputWriter;

    /**
     * The map that contains all the words of the input file and their
     * corresponding counts.
     */
    private Map<String, Integer> wordCount;

    /*
     * Private methods ---------------------------------------------------------
     */

    /**
     * This method adds all the words in the input file to this.wordCount and
     * keeps count of the words.
     *
     * @param input
     *            The SimpleReader inside the input file.
     */
    private void wordAndCountMap(SimpleReader input) {
        /*
         * While loop will continue until it goes through all the words in input
         */
        while (!input.atEOS()) {
            String content = input.nextLine(); //holds the nextLine of input
            int length = content.length();
            int position = 0; //start at position 0 in content
            String word = "";
            // We built the StringBuffer because FindBugs was giving us a warning
            StringBuffer wordBuilder = new StringBuffer();
            while (position < length) {
                // gets the character at the position
                char character = content.charAt(position);
                boolean isCharacter = Character.isLetter(character)
                        || character == '\'';
                if (isCharacter) { // if it is a character
                    while (isCharacter) { // while it is a word
                        /*
                         * While the loop keeps getting characters, it will
                         * concatenate the characters to the end of the
                         * WordBuider until it reaches an invalid char
                         */
                        wordBuilder.append(character);
                        position++; //increases the position
                        if (position != length) {
                            character = content.charAt(position);
                            isCharacter = Character.isLetter(character)
                                    || character == '\'';
                        } else {
                            /*
                             * If it reaches the length, there are no more
                             * characters left.
                             */
                            isCharacter = false;
                        }
                    }
                    // turns the StringBuffer into a string
                    word = wordBuilder.toString();
                    // checks to see if the word is in the map
                    boolean wordIsInMap = this.wordCount.hasKey(word);
                    if (wordIsInMap) {
                        Map.Pair<String, Integer> pair = this.wordCount
                                .remove(word);
                        int incrementCount = pair.value() + 1;
                        this.wordCount.add(pair.key(), incrementCount);
                    } else {
                        this.wordCount.add(word, 1);
                    }
                    position++; //increments the position
                    word = ""; //resets the word string
                } else {
                    position++; // if it's not a valid char, increments the position
                }
            }
        }
    }

    private void mapToSequence(int numberOfWords) {

    }

    /*
     * Creator of initial representation. --------------------------------------
     */

    /**
     * Creator of initial representation of Tag Cloud HTML object.
     *
     * @param input
     *            The full path of the input file.
     * @param output
     *            The full path of the output file.
     * @param numberOfWords
     *            The number of words that will be in the tag cloud.
     */
    private void createNewRep(String input, String output, int numberOfWords) {
        this.inputReader = new SimpleReader1L(input);
        this.outputWriter = new SimpleWriter1L(output);
        this.wordCount = new Map1L<String, Integer>();
        this.wordAndCountMap(this.inputReader);
        this.mapToSequence(numberOfWords);

        this.inputReader.close();
        this.outputWriter.close();
    }

    /*
     * Constructors ------------------------------------------------------------
     */

    /**
     * Constructor of the initial representation which calls createNewRep.
     *
     * @param inputFile
     *            The full path of the input file.
     * @param outputFile
     *            The full path of the output file.
     * @param numberOfWords
     *            The number of words that will be in the tag cloud.
     */
    public TagCloud(String inputFile, String outputFile, int numberOfWords) {
        this.createNewRep(inputFile, outputFile, numberOfWords);
    }

    /*
     * Public Methods ----------------------------------------------------------
     *
     * These are public methods that can be accessed from the TagCloudMain
     * class.
     */

    /*
     * Private nested classes --------------------------------------------------
     *
     * These are public methods that can be accessed from the TagCloudMain
     * class.
     */

    public static SortingMachine<Map.Pair<String, Integer>> sortMap(
            Map<String, Integer> wordCount, int numberOfWords) {

        return null;

    }

}
