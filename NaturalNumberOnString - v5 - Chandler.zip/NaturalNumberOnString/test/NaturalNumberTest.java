import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    /**
     * Tests the constructors with an empty string
     */
    @Test
    public void testConstructorWithEmptyString() {
        NaturalNumber first = this.constructorTest();
        NaturalNumber expected = this.constructorTest();
        assertEquals(first, expected);
    }

    /**
     * Tests the constructors with a string
     */
    @Test
    public void testConstructorWithString() {
        NaturalNumber first = this.constructorTest("54");
        NaturalNumber expected = this.constructorTest("54");
        assertEquals(first, expected);
    }

    /**
     * Tests the constructors with an integer
     */
    @Test
    public void testConstructorWithInteger() {
        NaturalNumber first = this.constructorTest(54);
        NaturalNumber expected = this.constructorTest(54);
        assertEquals(first, expected);
    }

    /**
     * Tests the constructors with a naturalnumber.
     */
    @Test
    public void testConstructorWithNaturalNumber() {
        NaturalNumber fiftyFour = new NaturalNumber1L(54);
        NaturalNumber first = this.constructorTest(fiftyFour);
        NaturalNumber expected = this.constructorTest(fiftyFour);
        assertEquals(first, expected);
    }

    /**
     * This tests the multiplyBy10() kernal method with a single digit.
     */
    @Test
    public void testMultiplyBy10() {
        NaturalNumber first = this.constructorTest("5");
        NaturalNumber expected = this.constructorRef("56");
        first.multiplyBy10(6);
        assertEquals(expected, first);
    }

    /**
     * This tests the multiplyBy10() kernal method with zero.
     */
    @Test
    public void testZeroMultiplyBy10() {
        NaturalNumber first = this.constructorTest();
        NaturalNumber expected = this.constructorRef("5");
        first.multiplyBy10(5);
        assertEquals(expected, first);
    }

    /**
     * This tests the multiplyBy10() kernal method with a large integer.
     */
    @Test
    public void testLargeNumberMultiplyBy10() {
        NaturalNumber first = this.constructorTest("6123");
        NaturalNumber expected = this.constructorRef("61235");
        first.multiplyBy10(5);
        assertEquals(expected, first);
    }

    /**
     * This tests the divideBy10() kernal method with a large integer
     */
    @Test
    public void testLargeNumberDivideBy10() {
        NaturalNumber first = this.constructorTest("3459567");
        NaturalNumber expected = this.constructorRef("345956");
        int check = first.divideBy10();
        assertTrue(check == 7);
        assertEquals(expected, first);

    }

    /**
     * This tests the divideBy10() kernal method with a regular integer
     */
    @Test
    public void testNumberDivideBy10() {
        NaturalNumber first = this.constructorTest("4");
        NaturalNumber expected = this.constructorRef("0");
        int check = first.divideBy10();
        assertTrue(check == 4);
        assertEquals(expected, first);
    }

    /**
     * This tests the divideBy10() kernal method with zero
     */
    @Test
    public void testZeroDivideBy10() {
        NaturalNumber first = this.constructorTest("0");
        NaturalNumber expected = this.constructorRef("0");
        int check = first.divideBy10();
        assertTrue(check == 0);
        assertEquals(expected, first);
    }

    /**
     * This tests the divideBy10() kernal method with an empty contructor which
     * equals 0.
     */
    @Test
    public void testEmptyZeroDivideBy10() {
        NaturalNumber first = this.constructorTest();
        NaturalNumber expected = this.constructorRef();
        int check = first.divideBy10();
        assertTrue(check == 0);
        assertEquals(expected, first);
    }

    /**
     * This tests the isZero() kernal method with an empty string.
     */
    @Test
    public void testIsZero() {
        NaturalNumber first = this.constructorTest();
        boolean check = first.isZero();
        assertTrue(check);
    }

    /**
     * This tests the isZero() kernal method with an integer.
     */
    @Test
    public void testIsNotZero() {
        NaturalNumber first = this.constructorTest("235");
        boolean check = first.isZero();
        assertTrue(!check);
    }
}
