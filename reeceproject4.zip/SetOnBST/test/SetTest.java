import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size

    // ----------- CONSTRUCTOR TESTS ------------------------------------------

    @Test
    public final void emptyConstructorTest() {
        Set<String> x = this.createFromArgsTest();
        Set<String> xExpected = this.createFromArgsRef();
        assertEquals(x, xExpected);
    }

    @Test
    public final void nonEmptySingleConstructorTest() {
        Set<String> x = this.createFromArgsTest("red");
        Set<String> xExpected = this.createFromArgsRef("red");
        assertEquals(x, xExpected);
    }

    @Test
    public final void nonEmptyMultiElementConstructorTest() {
        Set<String> xExpected = this.createFromArgsRef("red", "blue", "green");
        Set<String> x = this.createFromArgsTest("blue", "green", "red");
        assertEquals(x, xExpected);
    }

    @Test
    public final void nonEmptyMultiElementConstructorTest2() {
        Set<String> xExpected = this.createFromArgsRef("red", "blue", "green",
                "purple", "yellow");
        Set<String> x = this.createFromArgsTest("blue", "green", "red",
                "yellow", "purple");
        assertEquals(x, xExpected);
    }

    @Test
    public final void nonEmptySuperElementConstructorTest() {
        Set<String> xExpected = this.createFromArgsRef("a", "b", "c", "d", "e",
                "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p");
        Set<String> x = this.createFromArgsTest("p", "o", "n", "m", "l", "k",
                "j", "i", "h", "g", "f", "e", "d", "c", "b", "a");
        assertEquals(x, xExpected);
    }

    @Test
    public final void nonEmptyNumberElementConstructorTest() {
        Set<String> xExpected = this.createFromArgsRef("1", "2", "3", "4", "5",
                "6", "7", "8", "9", "10");
        Set<String> x = this.createFromArgsTest("10", "9", "8", "7", "6", "5",
                "4", "3", "2", "1");
    }

    // -------------- ADD TESTS -------------------------------------------------

    @Test
    public final void addElementsToEmptySet() {
        Set<String> x = this.createFromArgsTest();
        Set<String> xExpected = this.createFromArgsRef("Chandler", "Reece");
        x.add("Reece");
        x.add("Chandler");
        assertEquals(x, xExpected);
    }

    @Test
    public final void PRACTICE() {
        Set<String> x = this.createFromArgsTest("blue");
        Set<String> xExpected = this.createFromArgsRef("blue", "green", "red",
                "yellow", "purple");
        x.add("yellow");
        x.add("red");
        x.add("green");
        x.add("purple");
        assertEquals(x, xExpected);
    }

    @Test
    public final void addOneElementToSet() {
        Set<String> x = this.createFromArgsTest("green", "red", "yellow",
                "purple");
        Set<String> xExpected = this.createFromArgsRef("blue", "green", "red",
                "yellow", "purple");
        x.add("blue");
        assertEquals(x, xExpected);
    }

    @Test
    public final void addManyElementsToSet() {
        Set<String> x = this.createFromArgsTest();
        Set<String> xExpected = this.createFromArgsRef("blue", "green", "red",
                "yellow", "purple");
        x.add("purple");
        x.add("blue");
        x.add("green");
        x.add("red");
        x.add("yellow");
        assertEquals(x, xExpected);
    }

    //-------------REMOVE TESTS--------------------------------------------------

    @Test
    public final void removeSingleElementFromSet() {
        Set<String> x = this.createFromArgsTest("Chandler");
        Set<String> xExpected = this.createFromArgsRef();
        x.remove("Chandler");
        assertEquals(x, xExpected);
    }

    @Test
    public final void removeManyElementsFromSet() {
        System.out.println("START");
        Set<String> x = this.createFromArgsTest("blue", "green", "red",
                "yellow", "purple");
        System.out.println("START & Finish");
        Set<String> xExpected = this.createFromArgsRef("blue", "red");
        System.out.println("Our expected is: " + xExpected);
        System.out.println("What he have is: " + x);
        System.out.println("We are removing green.");
        x.remove("green");
        System.out.println("we are now removing yellow.");
        x.remove("yellow");
        System.out.println("we are now removing purple.");
        x.remove("purple");
        System.out.println(x); //-----------------------------------------------
        System.out.println(xExpected); //---------------------------------------
        assertEquals(x, xExpected);
    }

    //-------------REMOVE ANY TESTS---------------------------------------------
    @Test
    public final void removeAnySingleElementFromSet() {
        Set<String> x = this.createFromArgsTest("Chandler", "Reece");
        int xExpectedSize = 1;
        x.removeAny();
        assertEquals(x.size(), xExpectedSize);
    }

    @Test
    public final void removeAnymoreThanOneElement() {
        Set<String> x = this.createFromArgsTest("Yes", "no", "up", "down");
        int xExpectedSize = 2;
        x.removeAny();
        x.removeAny();
        assertEquals(x.size(), xExpectedSize);
    }

    @Test
    public final void removeAnyElementFromSetToMakeEmpty() {
        Set<String> x = this.createFromArgsTest("Chandler");
        int xExpectedSize = 0;
        x.removeAny();
        assertEquals(x.size(), xExpectedSize);
    }

    //-------------SIZE TESTS--------------------------------------------------
    @Test
    public final void sizeOfZero() {
        Set<String> first = this.createFromArgsTest();
        int size = first.size();
        assertEquals(size, 0);
    }

    @Test
    public final void sizeGreaterThanZero() {
        Set<String> first = this.createFromArgsTest("yes", "no", "up");
        int size = first.size();
        assertEquals(size, 3);
    }

    //-------------CONTAINS TESTS--------------------------------------------------
    @Test
    public final void doesNotContain() {
        Set<String> first = this.createFromArgsTest("Yes", "no", "up");
        boolean check = first.contains("down");
        assertEquals(check, false);
    }

    @Test
    public final void doesContain() {
        Set<String> first = this.createFromArgsTest("Yes", "no", "up");
        boolean check = first.contains("up");
        assertEquals(check, true);
    }

}
